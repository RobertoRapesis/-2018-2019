def sumIntervals(*setOfNums):       #Δηλωση Συνάρτησης με απεριόριστο περιθώριο παραμέτρων

    x=[]                            #
    allNums=[]                      #Δήλωση των list

    for nums in setOfNums:          #
        x.append(nums)              #Προσθήκη Στοιχείων στη Λίστα "x"




    for i in range (len(x)):        #
        a=x[i][0]                   #
        b=x[i][1]                   #
        d=b-a                       #
        for u in range(d):          #Πρόσθεση όλων των ενδιάμεσων αριθμών σε νέα λίστα "allNums"
            if a+u not in allNums:  #με την προϋπόθεση πως εμφανίζεται κάθε αριθμός απο μία φορά
                allNums.append(a+u) #στη λίστα

    print (len(allNums))            #Εκτύπωση Αποτελέσματος
 
# ΠΑΡΑΔΕΙΓΜΑΤΑ

sumIntervals( [1,2], [6, 10], [11, 15]  )                           #Επιστρέφει 9

sumIntervals( [1,4], [7, 10], [3, 5]  )                             #Επιστρέφει 7

sumIntervals( [1,5], [10, 20], [1, 6], [16, 19], [5, 11] )          #Επιστρέφει 19