import os                                       #
import random                                   #Χρήση Βιβλιοθηκών



fileName = os.path.basename(__file__)           #Ευρεση θεσης προγράμματος "proj11.py"



def getInput(text=1):                           #Αυτόματη συμπλήρωση του  full-path και εκτύπωση κατάλληλου μυνήματος
    if (text==1):
        file = os.path.abspath(__file__)[:-len(fileName)] + input('Name of text file :\n ')
        checkInput(file)
    elif (text==2):
        file = os.path.abspath(__file__)[:-len(fileName)] + input('Error : The file name you entered does NOT exist. Please enter a valid text file :\n')
        checkInput(file)



def checkInput(input):                          #Έλεγχος ύπαρξης αρχείου και εκτέλεση ανάλογης ενέργειας
    if os.path.isfile(input):
        initiate(input)
    else :
        getInput(2)



def initiate(input):   
    
                          
    f = open(input , 'r+')                      #
    fr = f.read()                               #
    f.close()                                   #Άνοιγμα του αρχείου και αποθήκευση του περιεχομένου του στη μεταβλητή "fr"


    w=0                                         #
    u=0                                         #
    p=0                                         #
    story=[]                                    #
    for i in fr:                                #
        u+=1                                    #
        if (i==' ')|(i=='\n'):                  #
            w+=1                                #
            if (w==3):                          #
                story.append(fr[p:u])           #
                p=u                             #
                w=0                             #Αποθήκευση του κειμένου σε list ανα διαδοχικές τριάδες



    random.shuffle(story)                       #
    txt=''                                      #
    for i in range(len(story)):                 #
        txt+=story[i]                           #
        txt=txt.replace('\n',' ')               #
    txt=txt.lower()                             #Ανακάτεμα τριάδων λέξεων και αποθήκευση αποτελέσματος στη μεταβλητή "txt" με ελάχιστες μετατροπές

    
    
    print (txt)                                 #Εκτύπωση νέου κειμένου (txt)

getInput()                                      #Κλήση της "getInput()"
