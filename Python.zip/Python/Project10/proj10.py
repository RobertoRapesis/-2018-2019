import urllib.request                                                           #Χρήση Βιβλιοθήκης

url = input('Enter the full URL of the page :\n ')                              #Λήψη URL απο τον χρήστη

page = urllib.request.urlopen(url)                                              #Αίτημα για επικοινωνία με σελίδα

source = page.read()                                                            #Ανάγνωση Κώδικα HTML

sourcestring = source.decode("utf-8")                                           #Μετατροπή σε string

num = sourcestring.count('<br>') + sourcestring.count('<p>')                    #Υπολογισμός του πλήθους των αλλαγών γραμμών (είτε με <br> είτε με <p>)

page.close()                                                                    #Τερματισμό επικοινωνίας με σελίδα

print ('The HTML page you provided has ' + str(num) + ' line breaks in total')  #Εκτύπωση Αποτελέσματος