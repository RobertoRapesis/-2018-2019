foo=' # foo'        #string 1
bar="bar # "        #string 2
foobar=foo+bar      #ένωση string1+string2
print(foobar)       #εκτώπωση αποτελέσματος
