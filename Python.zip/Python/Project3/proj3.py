import os

fileName = os.path.basename(__file__)           #Ευρεση θεσης προγράμματος "proj3.py"

def getInput(text=1):                           #Αυτόματη συμπλήρωση του  full-path και εκτύπωση κατάλληλου μυνήματος
    if (text==1):
        file = os.path.abspath(__file__)[:-len(fileName)] + input('Name of Python file :\n ')
        checkInput(file)
    elif (text==2):
        file = os.path.abspath(__file__)[:-len(fileName)] + input('Error : The file name you entered does NOT exist. Please enter a valid Python file :\n')


def checkInput(input):                          #Αποδοχή ονόματος αρχείου είτε εισαχθεί απο τον χρήστη το extention ".py" είτε όχι και έλεγχος ύπαρξης του αρχείου
    if os.path.isfile(input):
        if (str(input)[-3:] == '.py'):
            initiate(input)
    else :
        input=input + '.py'
        if os.path.isfile(input):
            initiate(input)
        else : getInput(2)                      #Επανάληψη διαδικασίας λόγω μη υπαρκτού αρχείου με το όνομα που εισήγαγε ο χρήστης

def initiate(input):
        
    fr = open(input , 'r+')                     #Άνοιγμα αρχείου για ανάγνωση
    new = fr.readlines()                        #Αποθήκευση αρχείου σε μορφή λίστας
    fr.close()                                  #Κλείσιμο αρχείου

    cl=0                                                                        #
    for line in new:                                                            #
        if (line[-3:]=='\n'):                                                   #
            new[cl]=line[:-3]                                                   #
        if('#' in line):                                                        #
                bfcom = line[:line.rfind('#')]                                  #
                if ((bfcom.count("'") % 2)==0)&((bfcom.count('"') % 2)==0):     #
                    new[cl]=new[cl][:line.rfind('#')]                           #Επεξεργασία της λίστας new:
                    new[cl]=new[cl]+'\n'                                        #Καθαρισμός των συμβόλων μόνο εάν αυτα δεν περικλείονται απο brackets τύπου <"> η <'>
        cl+=1                                                                   #καθώς και απαρίθμηση σειρών

    fw = open(input , 'w+')                                                     #Άνοιγμα αρχείου για τροποποίηση
    for i in range(cl):                                                         #
        fw.writelines(new[i])                                                   #Αντιγραφή της λίστας
    fw.close()                                                                  #Κλείσιμο αρχείου

getInput()                                                                      #Έναρξη της "getInput()"